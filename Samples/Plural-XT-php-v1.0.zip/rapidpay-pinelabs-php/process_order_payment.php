<?php
	//merchant configuration data
	$glb_rapidpay_merchant_id = 0;
	$glb_rapidpay_merchant_access_code = '';
	$glb_rapidpay_merchant_secret_key = '';
	$glb_rapidpay_merchant_return_url = '';
	$glb_rapidpay_merchant_gateway_mode = 'sandbox';
	$glb_rapidpay_merchant_payment_modes_csv = '';
	$glb_rapidpay_merchant_preferred_gateway = 'NONE';

	function rapidpay_hex2str($hex)
	{
		try
		{
		    $string = '';
		    
		    for ($i = 0; $i < strlen($hex) - 1; $i += 2)
		    {
		        $string .= chr(hexdec($hex[$i] . $hex[$i + 1]));
		    }
		    
		    return $string;
		}
		catch(Exception $e)
		{
			error_log("Exception in rapidpay_hex2str() function: " . $e);

			return '';
		}
	}

	function rapidpay_call_order_creation_api($url, $data, $x_verify)
	{
		try
		{
		   	$curl = curl_init();
			
			curl_setopt($curl, CURLOPT_POST, 1);
			
			if ($data)
			{
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
			}
			// OPTIONS:
			curl_setopt($curl, CURLOPT_URL, $url);

			curl_setopt($curl, CURLOPT_HTTPHEADER, array(
			  'X-VERIFY: ' . $x_verify,
			  'Content-Type: application/json',
			));

			curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);

			// EXECUTE:
			$result = curl_exec($curl);

			if (!$result) {
				die("Connection Failure");
			}

			curl_close($curl);

			return $result;
		}
		catch(Exception $e)
		{
			error_log("Exception in rapidpay_call_order_creation_api() function: " . $e);
		}
	}

	function rapidpay_configure_merchant($params)
	{
		try
		{
			global $glb_rapidpay_merchant_id, $glb_rapidpay_merchant_access_code, $glb_rapidpay_merchant_secret_key, $glb_rapidpay_merchant_return_url, $glb_rapidpay_merchant_payment_modes_csv, $glb_rapidpay_merchant_preferred_gateway, $glb_rapidpay_merchant_gateway_mode;

			$glb_rapidpay_merchant_id = array_key_exists('merchant_id', $params) ? $params['merchant_id'] : null;		
			$glb_rapidpay_merchant_access_code = array_key_exists('merchant_access_code', $params) ? $params['merchant_access_code'] : null;		
			$glb_rapidpay_merchant_secret_key = array_key_exists('merchant_secret_key', $params) ? $params['merchant_secret_key'] : null;		
			$glb_rapidpay_merchant_return_url = array_key_exists('merchant_return_url', $params) ? $params['merchant_return_url'] : null;		
			$glb_rapidpay_merchant_payment_modes_csv = array_key_exists('merchant_payment_modes_csv', $params) ? $params['merchant_payment_modes_csv'] : null;		
			$glb_rapidpay_merchant_preferred_gateway = array_key_exists('merchant_preferred_gateway', $params) ? $params['merchant_preferred_gateway'] : "NONE";		
			$glb_rapidpay_merchant_gateway_mode = array_key_exists('merchant_gateway_mode', $params) ? $params['merchant_gateway_mode'] : "sandbox";
		}
		catch(Exception $e)
		{
			error_log("Exception in rapidpay_configure_merchant() function: " . $e);
		}
	}

	function rapidpay_create_order($params)
	{	
		try
		{
			global $glb_rapidpay_merchant_id, $glb_rapidpay_merchant_access_code, $glb_rapidpay_merchant_secret_key, $glb_rapidpay_merchant_return_url, $glb_rapidpay_merchant_payment_modes_csv, $glb_rapidpay_merchant_preferred_gateway, $glb_rapidpay_merchant_gateway_mode;

			$merchant_data 							= new \stdClass();
			$merchant_data->merchant_return_url 	= $glb_rapidpay_merchant_return_url;
			$merchant_data->merchant_access_code 	= $glb_rapidpay_merchant_access_code;
			$merchant_data->order_id 				= array_key_exists('order_id', $params) ? $params['order_id'] : null;
			$merchant_data->merchant_id 			= $glb_rapidpay_merchant_id;
		                                               
			$payment_info_data 						= new \stdClass();
			$payment_info_data->amount 				= array_key_exists('amount_in_paisa', $params) ? $params['amount_in_paisa'] : null;
			$payment_info_data->currency_code 		= "INR";
			$payment_info_data->preferred_gateway 	= $glb_rapidpay_merchant_preferred_gateway;
			$payment_info_data->order_desc 			= array_key_exists('order_description', $params) ? $params['order_description'] : null;
		                                               
			$customer_data 							= new \stdClass();
			$customer_data->customer_id 			= array_key_exists('customer_id', $params) ? $params['customer_id'] : null;
			$customer_data->mobile_no 				= array_key_exists('mobile_no', $params) ? $params['mobile_no'] : null;
			$customer_data->email_id 				= array_key_exists('email_id', $params) ? $params['email_id'] : null;
		                                               
			$billing_address_data 					= new \stdClass();
			$billing_address_data->first_name 		= array_key_exists('first_name', $params) ? $params['first_name'] : null;
			$billing_address_data->last_name 		= array_key_exists('last_name', $params) ? $params['last_name'] : null;
			$billing_address_data->address1 		= array_key_exists('address1', $params) ? $params['address1'] : null;
			$billing_address_data->address2 		= array_key_exists('address2', $params) ? $params['address2'] : null;
			$billing_address_data->address3 		= array_key_exists('address3', $params) ? $params['address3'] : null;
			$billing_address_data->pincode 			= array_key_exists('pincode', $params) ? $params['pincode'] : null;
			$billing_address_data->city 			= array_key_exists('city', $params) ? $params['city'] : null;
			$billing_address_data->state 			= array_key_exists('state', $params) ? $params['state'] : null;
			$billing_address_data->country 			= array_key_exists('country', $params) ? $params['country'] : null;
		                                               
			$shipping_address_data 					= new \stdClass();
			$shipping_address_data->first_name 		= array_key_exists('ship_first_name', $params) ? $params['ship_first_name'] : null;
			$shipping_address_data->last_name 		= array_key_exists('ship_last_name', $params) ? $params['ship_last_name'] : null;
			$shipping_address_data->address1 		= array_key_exists('ship_address1', $params) ? $params['ship_address1'] : null;
			$shipping_address_data->address2 		= array_key_exists('ship_address2', $params) ? $params['ship_address2'] : null;
			$shipping_address_data->address3 		= array_key_exists('ship_address3', $params) ? $params['ship_address3'] : null;
			$shipping_address_data->pincode 		= array_key_exists('ship_pincode', $params) ? $params['ship_pincode'] : null;
			$shipping_address_data->city 			= array_key_exists('ship_city', $params) ? $params['ship_city'] : null;
			$shipping_address_data->state 			= array_key_exists('ship_state', $params) ? $params['ship_state'] : null;
			$shipping_address_data->country 		= array_key_exists('ship_country', $params) ? $params['ship_country'] : null;

			$product_details 						= new \stdClass();
			$product_details->product_code 			= array_key_exists('product_code', $params) ? $params['product_code'] : null;
			$product_details->product_amount 		= array_key_exists('product_amount_in_paisa', $params) ? $params['product_amount_in_paisa'] : null;
			
			$product_info_data = new \stdClass();

			$product_info_data->product_details[0] = $product_details;
		                                               
			$additional_info_data 					= new \stdClass();
			$additional_info_data->rfu1 			= array_key_exists('rfu1', $params) ? $params['rfu1'] : null;

			$orderData = new \stdClass();

			$orderData->merchant_data = $merchant_data;
			$orderData->payment_info_data = $payment_info_data;
			$orderData->customer_data = $customer_data;
			$orderData->billing_address_data = $billing_address_data;
			$orderData->shipping_address_data = $shipping_address_data;
			$orderData->product_info_data = $product_info_data;
			$orderData->additional_info_data = $additional_info_data;

			$orderData = json_encode($orderData);

			$requestData = new \stdClass();
			$requestData->request = base64_encode($orderData);

			$x_verify = strtoupper(hash_hmac("sha256", $requestData->request, rapidpay_hex2str($glb_rapidpay_merchant_secret_key)));

			$requestData = json_encode($requestData);

			$rapidPayHostUrl = 'http://localhost:51462';
			
			if ($glb_rapidpay_merchant_gateway_mode == 'sandbox')
			{
				$rapidPayHostUrl = 'http://localhost:51462';
			}

			$orderCreationUrl = $rapidPayHostUrl . '/api/v2/order/create';
			$order_creation = rapidpay_call_order_creation_api($orderCreationUrl, $requestData, $x_verify);

			$response = json_decode($order_creation, true);

			return $response;
		}
		catch(Exception $e)
		{
			error_log("Exception in rapidpay_create_order() function: " . $e);

			return null;
		}
	}

	function rapidpay_redirect_after_order_creation($token)
	{	
		try
		{
			global $glb_rapidpay_merchant_payment_modes_csv;

			$rapidPayHostUrl = 'http://localhost:51462';
			
			if ($glb_rapidpay_merchant_gateway_mode == 'sandbox')
			{
				$rapidPayHostUrl = 'http://localhost:51462';
			}

			$payment_redirect_url = $rapidPayHostUrl . '/pinepg/v2/process/payment/redirect?orderToken=' . $token . '&paymentmodecsv=' . $glb_rapidpay_merchant_payment_modes_csv;

			header("Location: $payment_redirect_url");
			
			die();
		}
		catch(Exception $e)
		{
			error_log("Exception in redirect_after_order_creation() function: " . $e);
		}
	}

?>