<?php
  	include 'process_order_payment.php';

  	//merchant configuration
	$merchant_data = array(
							'merchant_id' => '3413',
							'merchant_access_code' => '1c295f88-4477-4cd3-b5ac-e76148545a3e',
							'merchant_secret_key' => '46AC6117F2104F91B554F3E35DCEFE41',
							'merchant_return_url' => 'http://localhost/rapidpay-pinelabs-php/response_page.php',
							'merchant_gateway_mode' => 'sandbox',
							'merchant_payment_modes_csv' => '1,2,3,4',
							'merchant_preferred_gateway' => 'HDFC',
						);

	rapidpay_configure_merchant($merchant_data);

	$postdata = $_REQUEST;

	//create order
	$order_creation_response = rapidpay_create_order($postdata);	

	$response_code = null;
	$token = null;

	if (!empty($order_creation_response))
	{	
		if (array_key_exists('response_code', $order_creation_response))
		{	
			$response_code = $order_creation_response['response_code'];
		}

		if (array_key_exists('token', $order_creation_response))
		{
			$token = $order_creation_response['token'];
		}	
	}

	if ($response_code != 1 || empty($token))
	{
		echo "Order creation failed";
		
		exit;
	}

	//redirect to payment gateway
	rapidpay_redirect_after_order_creation($token);

	exit;
?>